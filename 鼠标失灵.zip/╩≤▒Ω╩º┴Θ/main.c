# include <windows.h>
# include <stdio.h>
int main(void)
{
 int x,y;
 while(1)//死循环
 {
 x = rand()%801;//随机数
 y = rand()%601;//随机数
 SetCursorPos(x,y);//鼠标定位
 }
 return 0 ;
}